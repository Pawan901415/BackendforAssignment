namespace JwtRoleAuthentication.Models;

public class PagesDto
{
    public List<PageDto> Pages { get; set; } = new List<PageDto>();
}