namespace JwtRoleAuthentication.Enums;

public enum Role
{
    Admin,
    User
}